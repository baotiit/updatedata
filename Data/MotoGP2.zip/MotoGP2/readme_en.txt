
    MOTOGP2 RELEASE NOTES

    Last updated: April 28, 2003




DEFAULT CONTROLS

Menu keys:
    Cursor keys - change selection
    Space or Enter - select
    Esc - go back
    Tab - special functions (see bottom of screen)
    Delete - delete a custom rider or player profile
    C - copy layer in the logo editor
    V - paste layer in the logo editor
    Numeric keypad 2/4/6/8 - rotate and zoom bike models

Game keys:
    Left - steer and lean the bike to the left
    Right - steer and lean the bike to the right
    Up - accelerate
    Down - apply front and rear brakes evenly
    D - lean the rider forward on the bike
    C - lean the rider back on the bike
    X - apply the front brake
    Z - apply the rear brake
    Q - glance behind you
    W - change the camera view
    Esc - pause the game

Tip: lean forward for greater speed and stability on straights. Lean back to 
slow down and perform wheelies.

Tip: powerslide around corners by double-tapping the accelerator. This will 
cause the rear wheel to spin and allow you drift the rear end of the bike.

Tip: applying the rear brake (Z) allows the rider to skid the rear end of 
their bike.

Tip: applying the front brake (X) allows the rider to perform tricks such as 
endos and burnouts.

Tip: The left and right Ctrl keys control the flippers in the pinball
minigame.  Use the right flipper to start the game.

Note: After plugging in a controller (gamepad, joystick, etc), you must go
into the "Configure Controllers" menu of the launcher, even if you plan to
use the default configuration.

MotoGP2 has been tested with the following peripherals:

    Logitech Wingman extreme. 
    Logitech Wingman Rumble pad. 
    Microsoft Sidewinder Gamepad pro. 
    Microsoft Sidewinder. 
    Microsoft Sidewinder Force Feedback Pro steering wheel.
    Interact Axis Pro. 
    Interact Hammerhead. 

Other DirectX compatible peripherals may work with MotoGP 2 but have not
been tested. 






GRAPHICS CARD COMPATIBILITY

MotoGP has been tested on these cards:

    nVidia GeForce4 TI
    nVidia GeForce2 GTS
    nVidia GeForce2 MX
    nVidia GeForce 256
    nVidia Riva TNT2

    ATI Radeon 9700
    ATI Radeon 8500
    ATI Rage Fury Maxx

    Matrox Parhelia
    Matrox G400
    Matrox G200

    PowerVR Kyro II

    3dfx Voodoo5
    3dfx Voodoo3

It is likely to work on any similar DirectX 9 compatible 3D cards, but this 
has not been tested.

It is very important that you install the latest drivers for your card 
before running MotoGP, as there are known problems with older drivers on 
most of the hardware listed above. You can download current drivers from the 
manufacturer websites:

    nVidia - http://www.nvidia.com/content/drivers/drivers.asp
    ATI - http://www.ati.com/support/driver.html
    Matrox - http://www.matrox.com/mga/support/drivers/home.cfm
    PowerVR - http://www.powervr.com/Downloads.asp
    Intel - http://support.intel.com/support/graphics
    3dfx - http://www.voodoofiles.com/3dfxhelp.asp




TROUBLESHOOTING

Before installing the game, please make sure the destination drive has 
enough free space. If the install program warns you that there is not enough 
room, you should either remove other programs to free up space, or back up 
and select one of the partial install options (which will give slower 
loading times but require less room on your hard drive).

The install directory name should not be longer than about 200 characters. 
If it is too long, the install will not work correctly.

The game may not run correctly on computers that have virtual memory 
disabled. If you have turned this off, you can reactivate it in the Windows 
Control Panel.

Some video card drivers contain optimisations that can interfere with the 
responsiveness of the game. If you find that this is happening try setting 
Triple Buffered to on under the Advanced Video Mode Settings.

The unlockable wireframe rendering mode may perform badly on some cards, as 
wireframe rendering can be extremely slow on hardware that was not optimised 
for it.

Due to an ATI driver bug, MotoGP2 has been known to crash when 'Use hardware 
T&L' is switched off on computers using ATI video cards.




DISPLAY SETTINGS

The Configure Game button in the launcher program lets you tweak MotoGP to 
get the most out of your hardware. Here are a few hints on which settings 
are the most important, and what you want to avoid...


    Resolution - choose whatever you like, but it looks better in lower 
    resolutions (eg. 800x600) with all the effects turned on than in high 
    resolution with them disabled.

    Graphics detail - this slider allows you to choose the graphics detail. 
    Generally the lower this is set the smoother the game will run. Change 
    this if you want better performance or better graphics.

    Number of bikes - turning down the number of bikes is a great way to 
    make the game run quickly even with everything else turned on, but then 
    again, winning a race with only 8 bikes just isn't the same as getting 
    out in front of a pack of 20...

    Set your network connection type accurately to improve consistency in 
    network games. The game will then adjust its bandwidth usage to match 
    your connection type.


Advanced Video Mode Settings:

    Warning: changing these settings may stop the game from working 
    correctly. If you encounter problems, click on the 'Reset Defaults' 
    button to go back to the original values.

    Color depth - makes surprisingly little difference. Obviously the image 
    quality is better in 24 or 32 bit than in 16 bit mode, but you won't 
    lose any features or effects if you set it to use 16 bit color.

    Z depth - this controls both how many bits of zbuffer precision are 
    available, and also whether the zbuffer will include stencil 
    information. If there is only one number (eg. "32 bit"), this means 
    there is only z data, but if there are two (eg. "32 bit (24.8)"), that 
    means the buffer is split into 24 bits of z and 8 of stencil. MotoGP 
    will work with any format of zbuffer, but at least 24 bit z is 
    recommended to avoid sorting problems on distant objects, and a stencil 
    buffer is highly recommended because without it we will be unable to 
    display proper shadows or reflections on wet days. The best format is 
    24.8 z and stencil. Failing that 24.4 or 15.1 are ok, but you should 
    only use the simple 16 or 32 bit formats if your card doesn't support 
    stencil buffers at all.
    
    Antialiasing - as well as conventional fullscreen antialiasing, MotoGP 
    supports a full screen special effects mode that enables motion blur, 
    accurate reflections of the environment during rainy days, and on pixel 
    shader hardware, refractive raindrops on the camera lens. Use of this 
    mode is highly recommended if your card is powerful enough to support 
    it, but you may find it is too slow especially if you are running in a 
    high resolution.


Advanced Graphics Detail Settings:

    Warning: changing these settings may stop the game from working 
    correctly. If you encounter problems, click on the 'Reset Defaults' 
    button to go back to the original values.

    Texture resolution - MotoGP automatically scales the texture resolution 
    according to how much memory is available in your card, so you will 
    normally want to leave this slider in the center. Moving it to the right 
    will force it to use a higher resolution than the autodetection would 
    normally select, which may give better results but runs the risk of poor 
    performance.

    Multitexture layers - the landscape can be drawn using anywhere from 1 
    to 4 layers of multitexturing. Turn this up if your card can handle it, 
    or down if you need to make things run faster.

    Texture sharpness - this lets you adjust the point where your card will 
    switch between texture mipmaps. Moving it to the right will make the 
    textures look sharper and higher resolution, but at the cost of some 
    shimmering and flicker. Moving it to the left will give a much smoother, 
    more antialiased look, but without such good texture resolution.




NETWORKING

As mentioned above, setting the connection type is really important if you 
want smooth and consistent network games.


Analog modems:

    If you are playing over a 56k modem, your limited bandwidth will detract 
    from the game's quality, so it's highly recommended that you either 
    reduce the number of bikes in the race (using the Game Settings tab in 
    the Configure Game section of the launcher), or turn off AI bikes 
    altogether in the Edit Game Mode menu of the host machine (press Tab 
    from the lobby to get there) and avoid sessions with more than 8 players.


NATs:

    As MotoGP uses a peer-to-peer protocol, it may not function correctly if 
    players are behind NATs (Network Address Translators). However, 
    depending upon the NAT and its configuration, it may work provided the 
    host of the session is not behind a NAT.

    If you experience problems such as not being able to join a session, or 
    dropping out of a session with no apparent cause, or just finding that 
    some players are not racing around the track, you may need to alter your 
    NAT configuration.

    Make sure UDP traffic is allowed.

    If possible: disable any firewalling options which would reject packets 
    from unknown remote hosts.

    Ideally: set your PC to be the "DMZ host", or map UDP traffic on port 
    41455 on your PC through a fixed port on the NAT (41455 is good, but 
    other ports should work too).

    Doing this may also allow you to host from behind your NAT, if players 
    connect to the port you mapped on the NAT.




HOW TO PLAY MOTOGP2 IN GAMESPY ARCADE

You can play MotoGP2 online through GameSpy Arcade, which comes conveniently 
bundled with the game. If you haven't done so already, insert your MotoGP2 
CD and install Arcade now. Then, to play MotoGP2 online, just follow these 
simple instructions.


Launch GameSpy Arcade and Go to the MotoGP2 Room:

    Click on the GameSpy Arcade link in your Start Menu. When the software 
    starts, you'll see a list of games and more along the left-hand side. 
    There's plenty to do, but there's time for that later: Click on the 
    MotoGP2 button on the left to enter the MotoGP2 room.


Find or Start a MotoGP2 Server:

    Once you're in the MotoGP2 room you can meet or greet other players, 
    find servers or create your own server. The top half of the application 
    will list all of the available servers, including the number of people 
    playing and your connection speed (measured by something called "ping." 
    The lower your ping, the better.) Don't like any servers? Click on the 
    "Create Room" button to start your own server and wait for people to 
    sign up. Otherwise, double-click on a server of your choice to join in.


Joining and Starting a game:

    Once you double-click on a server or start your own, you'll be in a 
    staging room, in which you can trash talk with your fellow players and 
    prepare for combat. When you're ready to play, click the "Ready" button 
    at the top of the screen. When everyone in the room has signaled their 
    readiness, the host can then launch the game. Arcade will fire up MotoGP 
    2 and the carnage will begin!


Problems?

    If you have problems using Arcade, whether installing the program, 
    registering it, or using it in conjunction with MotoGP2, consult our 
    help pages, located at http://www.gamespyarcade.com/help/ or e-mail us 
    by using the form located at 
    http://www.gamespyarcade.com/support/contact.shtml.




CREDITS

Jon Gibson - Producer
Alys Elwick - Assistant Producer

Shawn Hargreaves - Lead Programmer
Damyan 'Doctor' Pepper - Programmer
gavin 'elf23' norman - programmer
Sir George of Foot - Programmer
Matthew Hill - Programmer
Peter 'Smokey' Pimley - Programmer
Chris Caulfield - Dyne Physics Engine

Jason 'J' Green - Lead Artist
Gylan Hunter - Animator
Harvey Parker - Artist
Henry Rolls - Artist
Justin 'The Beaver' Bravery - Artist
Lawrence 'The Lorenzo' Elwick - Artist
Marco 'Coriander' Hallett - Artist
Paul 'Meston' Meston - Artist
Paul 'Splat' Shewan - Artist
Fizzy Pete Butler - Artist
Rory 'Dr Rodriguez' Walker - Artist
Ryan 'Brian' Guy - Artist
Mark Hill - Additional Artwork

Luke Smith - Lead Designer
Akin Marquis - Designer
Richard Stone - Designer

Adam Pitt - Sound
Keith Clarke - Sound

Steve Brocking - QA

Original Game Also Featured:
    Rik Alexander - Producer
    Mike Patrick - Designer
    Alastair Cornish, Alkan Hassan - Additional Design
    Adam Sawkins - Additional Programming
    Flack - Additional Programming
    Ross Childs - Additional Programming
    Boris Lowinger - Animator
    Jason McFee - Artist
    Barny - Additional Artwork
    Jez White - Additional Artwork

Music:
    Psynn2 (Menus) - Shawn Hargreaves
    Firebird (Suzuka) - V8 Pack
    Devil's Dice (Phakisa) - V8 Pack
    Oil (Jerez) - Third Girl
    5700 cc's (Le Mans) - V8 Pack
    Adrenalin (Mugello) - Darrin Roggenkamp
    Fastback Reptile Combo (Catalunya) - V8 Pack
    Gasoline Overlord (Assen) - V8 Pack
    Sabretooth (Donington) - V8 Pack
    Sleazy Rider (Sachsenring) - Third Girl
    Chrome Rider (Brno) - V8 Pack
    Eat Dirt (Estoril) - Third Girl
    10-4 Rocker (Rio) - V8 Pack
    Metropolis (Motegi) - V8 Pack
    Needle (Sepang) - Darrin Roggenkamp
    Power Up (Phillip Island) - V8 Pack
    Doug McClure (Valencia) - V8 Pack
    Slipstream (Sheridan Circuit) - Third Girl
    Cookin' on Electric (Credits) - Third Girl

Guy Mayhem, Rupert Mills - MIS

Lynn Horton, Mel Ward - Office Admin

Craig Gabell - Art Director
Greg Michael - Technical Director
Nick Baynes - Development Director
Tony Beckwith - The Boss
Gary Liddon - Another Boss
Karl Jeffery - King

THQ International:
    Mike Gamble - Director of European Development
    Iain Riches - Project Manager
    Phil Wright - Assistant Project Manager
    Michael Pattison - Head of Brand Management
    Jennifer Wyatt - Brand Manager
    Darren Williams - Associate Brand Manager
    Jon Brooke - UK + Export Marketing Manager
    Markus Schuetze - Germany Product Manager
    Olivier Perron - France Senior Product Manager
    Sophie Mavridis - Asia Pacific Marketing Director

THQ USA:
    Jack Sorensen - Executive VP of Worldwide Studios
    Philip Holt - VP of Product Development
    James Boone - Executive Producer
    Raphael Hernandez - Producer
    Michael Motoda - Associate Producer
    Jason Garwood - Assistant Producer
    Peter Dille - VP of Marketing
    Liz Pieri - Director of Public Relations
    Reilly Brennan - Public Relations Manager
    Howard Liebenskind - Director of Creative Services
    Kathy Helgason - Senior Manager of Creative Services
    Mellisa Roth - Assoc. Manager of Creative Services
    Laura Naviaux - Marketing Project Manager
    David Newman - Marketing Project Coordinator
    Jeremy S. Barnes - Director of Quality Assurance
    Monica Vallejo - QA Manager
    Jason Roberts - QA Database Administrator
    Danny Smith - Lead Tester
    Brian Skidmore, Ray Ploesser - Testers
    Luis Sanchez, Jason Donaghe - Testers
    Mario Waibel, Brian McElroy - QA Technicians

Special Thanks:
    Alison Forth (Team Yamaha)
    Team Sabre Sport
    Paul Wilson
    Randy Mamola
    Andrew Whitney
    Jon Attaway
    Augustin Jean Fresnel
    Xiph.org (Ogg Vorbis)
    Jordan Russell (Inno Setup)
    Avery Lee (VirtualDub)
    Cygwin
    The Free Software Foundation
    Piers 'DM2' Newman
    Tony 'Big Mal' Morris




LICENSE AGREEMENT

Your use of the file is evidence of your agreement to be bound by the terms.

1. OWNERSHIP. The Software is and shall remain a proprietary product of THQ 
and its suppliers. THQ and its suppliers shall retain ownership of all 
patents, copyrights, trademarks, trade names, trade secrets and other 
proprietary rights relating to or residing in the Software. Except as 
provided in Section 2, you shall have no right, title or interest in or to 
the Software. The Software is licensed, not sold, to you for use only under 
the terms of this Agreement. If you agree to be bound by all of the terms of 
this Agreement, you will only own the media on which the Software has been 
provided and not the Software itself.

2. GRANT OF LICENCE. THQ grants you a non-exclusive, non-transferable right 
to use one copy of the Software in the country in which you acquired the 
Software for your own personal use. All other rights are expressly reserved 
by THQ. You may not: (a) install the Software on multiple computers, 
timeshare the Software, or make it available to multiple persons, (b) 
reverse-engineer or decompile the Software, or (c) export the Software. You 
may make one copy of the Software solely for purposes of having a backup 
copy, provided that you reproduce on that copy all copyright notices and any 
other confidentiality or proprietary legends that are on the original copy 
of the Software. You understand that THQ or its suppliers may update the 
Software at any time and in doing so incurs no obligation to furnish such 
updates to you pursuant to this Agreement.

3. LIMITED WARRANTY. THQ warrants that the media on which the Software is 
provided will be free from faulty workmanship and defective materials for a 
period of ninety (90) days from your date of receipt of the Software. This 
limited warranty is void if failure of the Software to conform with the 
warranty has resulted from improper installation, misuse, neglect, accident, 
fire or other hazard, or after any breach of this Agreement. In the event of 
a breach of the foregoing limited warranty, you must return the Software to 
THQ or the THQ-authorised distributor that provided you with the Software, 
postage prepaid, before the expiration of the warranty period, with a copy 
of the invoice for the Software and this signed Agreement. THQ and its 
suppliers sole and exclusive liability and your sole and exclusive remedy 
shall be, at THQ sole discretion, either to (i) provide a replacement copy 
of the Software or (ii) refund the license fee you paid and terminate this 
Agreement. The replacement copy will be warranted for ninety (90) days. 
OTHER THAN THE FOREGOING LIMITED WARRANTY, WHICH IS MADE SOLELY BY THQ AND 
NOT BY ANY THQ SUPPLIER, THE SOFTWARE IS BEING LICENSED TO YOU IS, WITHOUT 
ANY WARRANTY OF ANY KIND. THQ AND ITS SUPPLIERS DISCLAIM ALL OTHER 
WARRANTIES, EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION THE WARRANTIES 
OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, TITLE AND 
NONINFRINGEMENT OF THIRD PARTY RIGHTS. SOME JURISDICTIONS DO NOT ALLOW THE 
DISCLAIMER OF IMPLIED WARRANTIES, SO THE ABOVE DISCLAIMER MAY NOT APPLY TO 
YOU, IN WHICH CASE THE DURATION OF ANY SUCH IMPLIED WARRANTIES IS LIMITED TO 
NINETY (90) DAYS FROM THE DATE THE SOFTWARE IS RECEIVED BY YOU. THIS 
WARRANTY GIVES YOU SPECIFIC LEGAL RIGHTS. YOU MAY HAVE OTHER LEGAL RIGHTS 
WHICH VARY FROM JURISDICTION TO JURISDICTION.

4. LIMITATION OF LIABILITY. IN NO EVENT SHALL THQ AGGREGATE LIABILITY IN 
CONNECTION WITH THIS AGREEMENT AND THE SOFTWARE, REGARDLESS OF THE FORM OF 
THE ACTION GIVING RISE TO SUCH LIABILITY (WHETHER IN CONTRACT, TORT OR 
OTHERWISE), EXCEED THE LICENSE FEES RECEIVED BY THQ FOR THE SOFTWARE. NO THQ 
SUPPLIER SHALL HAVE ANY LIABILITY WHATSOEVER UNDER THIS AGREEMENT. IN NO 
EVENT SHALL THQ OR THQ SUPPLIERS BE LIABLE FOR ANY INDIRECT, EXEMPLARY, 
SPECIAL, CONSEQUENTIAL OR INCIDENTAL DAMAGES OF ANY KIND (INCLUDING WITHOUT 
LIMITATION LOST PROFITS), EVEN IF THQ OR SUCH SUPPLIER HAS BEEN ADVISED OF 
THE POSSIBILITY OF SUCH DAMAGES. SOME JURISDICTIONS DO NOT ALLOW THE 
LIMITATION OR EXCLUSION OF LIABILITY FOR CONSEQUENTIAL OR INCIDENTAL DAMAGES 
SO THE ABOVE LIMITATION OR EXCLUSION MAY NOT APPLY TO YOU. THQ SHALL NOT BE 
LIABLE FOR ANY CLAIMS OF THIRD PARTIES RELATING TO THE SOFTWARE. THE LIMITED 
WARRANTY, LIMITED REMEDIES AND LIMITED LIABILITY PROVISIONS CONTAINED IN 
THIS AGREEMENT ARE FUNDAMENTAL PARTS OF THE BASIS OF THQ BARGAIN HEREUNDER, 
AND THQ WOULD NOT BE ABLE TO PROVIDE THE SOFTWARE TO YOU WITHOUT SUCH 
LIMITATIONS. SOME JURISDICTIONS DO NOT ALLOW THE LIMITATION OR EXCLUSION OF 
LIABILITY, SO THE ABOVE DISCLAIMER MAY NOT APPLY TO YOU, IN WHICH CASE THE 
DURATION OF ANY SUCH LIMITATION OR EXCLUSION OF LIABILITY IS LIMITED TO 
NINETY (90) DAYS FROM THE DATE THE SOFTWARE IS RECEIVED BY YOU. THIS 
WARRANTY GIVES YOU SPECIFIC LEGAL RIGHTS. YOU MAY HAVE OTHER LEGAL RIGHTS 
WHICH VARY FROM JURISDICTION TO JURISDICTION.

5. TERMINATION. You may terminate this Agreement at any time. This Agreement 
shall terminate automatically upon your breach of any term of this 
Agreement. Upon termination, you shall destroy the Software and the backup 
copy, if any, you made pursuant to the Agreement.

THQ and the THQ logo are trademarks and/or registered trademarks of THQ Inc. 
All rights reserved.


